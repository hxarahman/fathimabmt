-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 29, 2023 at 09:45 AM
-- Server version: 10.5.19-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u333218349_fathimabmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL,
  `date_updated` varchar(100) NOT NULL,
  `date_uploaded` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `image`, `date_updated`, `date_uploaded`) VALUES
(1, 'images/brands/01.png', '', '11:26 / 19 Nov 2020'),
(2, 'images/brands/02.png', '', '11:26 / 19 Nov 2020'),
(3, 'images/brands/03.png', '', '11:26 / 19 Nov 2020'),
(4, 'images/brands/04.png', '', '11:26 / 19 Nov 2020'),
(5, 'images/brands/05.png', '', '11:26 / 19 Nov 2020'),
(6, 'images/brands/06.png', '', '11:26 / 19 Nov 2020'),
(7, 'images/brands/07.png', '', '11:26 / 19 Nov 2020'),
(8, 'images/brands/08.png', '', '11:26 / 19 Nov 2020'),
(9, 'images/brands/09.png', '', '11:26 / 19 Nov 2020'),
(10, 'images/brands/10.png', '', '11:26 / 19 Nov 2020');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `date_updated` varchar(100) DEFAULT NULL,
  `date_uploaded` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `name_ar`, `image`, `date_updated`, `date_uploaded`) VALUES
(1, 'HARDWARE MATERIALS', 'مواد الأجهزة', 'images/cats/hardware.png', NULL, '11:26 / 19 Nov 2020'),
(2, 'SAFETY PRODUCTS', 'منتجات السلامة', 'images/cats/safety.png', NULL, '11:26 / 19 Nov 2020'),
(3, 'MARINE COMMERCIAL WHITE WOOD', 'خشب أبيض تجاري بحري', 'images/cats/material.png', NULL, '11:26 / 19 Nov 2020');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `is_solved` tinyint(1) NOT NULL DEFAULT 0,
  `date_uploaded` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `name`, `email`, `phone`, `subject`, `message`, `is_solved`, `date_uploaded`) VALUES
(1, 'Tester', 'Test@fathimabmt.com', '+971561267009', 'For Test', 'I am Testing The Enquiry Box', 0, '04:38 / 20 Nov 2020'),
(2, 'admin', 'asas@gsadh.com', '9834235234', 'Testing ', 'Hello', 1, '12:55 / 21 Nov 2020');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL,
  `date_updated` varchar(100) NOT NULL,
  `date_uploaded` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `image`, `date_updated`, `date_uploaded`) VALUES
(1, 'images/gallery/gal1.jpg', '', '11:26 / 19 Nov 2020');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `date_updated` varchar(100) NOT NULL,
  `date_uploaded` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `name_ar`, `image`, `category`, `date_updated`, `date_uploaded`) VALUES
(1, 'A2 ARBOUR', 'A2 ARBOUR', 'images/product/a2-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(2, 'ADJUSTABLE SPANNER', 'مفتاح براغي قابل للتعديل', 'images/product/spanner-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(3, 'ANCHOR BOLT', 'مرساة الترباس', 'images/product/a3-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(4, 'CLAW HAMMER', 'مخلب مطرقة', 'images/product/hammer-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(5, 'GI WASHER FOR PLASTER WORK', 'GI WASHER لأعمال الجبس', 'images/product/plaster-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(6, 'GRINDING DISK', 'قرص طحن', 'images/product/a4-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(7, 'STEEL GURMALA', 'الصلب GURMALA', 'images/product/a5-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(8, 'WATER LEVEL PIPE', 'مستوى الماء الأنابيب', 'images/product/a6-500x320.png', 'HARDWARE MATERIALS', '', '11:26 / 19 Nov 2020'),
(9, 'DUST MASK', 'قناع الغبار', 'images/product/c1-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(10, 'GREEN MESH', 'شبكة خضراء', 'images/product/c2-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(11, 'GUM BOOT', 'التمهيد اللثة', 'images/product/c3-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(12, 'HAND GLOVES DOTTED', 'قفازات يدوية منقطة', 'images/product/c4-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(13, 'ORANGE MESH', 'شبكة البرتقال', 'images/product/c7-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(14, 'SAFETY HARNESS', 'تسخير السلامة', 'images/product/c5-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(15, 'SAFTEY HELMET-RED', 'خوذة أمان-أحمر', 'images/product/helmet-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(16, 'TRAFFIC CONE', 'مخروط المرور', 'images/product/c6-500x320.png', 'SAFETY PRODUCTS', '', '11:26 / 19 Nov 2020'),
(17, 'COMMERCIAL PLYWOOD 12MM', 'خشب رقائقي تجاري 12 ملم', 'images/product/b1-500x320.png', 'MARINE COMMERCIAL WHITE WOOD', '', '11:26 / 19 Nov 2020'),
(18, 'MARINE BROWN FILM FACE PLYWOOD', 'مارين فيلم بني للوجه خشب رقائقي', 'images/product/b2-500x320.png', 'MARINE COMMERCIAL WHITE WOOD', '', '11:26 / 19 Nov 2020'),
(19, 'MDF BOARD 3MM', ' لوح3  MDF مللي متر ', 'images/product/b3-500x320.png', 'MARINE COMMERCIAL WHITE WOOD', '', '11:26 / 19 Nov 2020');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(1, 'admin', 'info@fathimabmt.com', 'Fathimabmt@admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
