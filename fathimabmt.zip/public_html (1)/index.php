<?php

require 'DBconfig.php';

include "cookie.php";
include "lang.php";
include "header.php";
include "footer.php";
include "get.php";

?>

        <?php echo $home."active"; ?>
        <?php echo $about; ?>
        <?php echo $product; ?>
        <?php echo $gallery; ?>
        <?php echo $header; ?>
        <!-- START SLIDER -->

        <div class="slide_show">
          <div class="imageSlides visible">  
              <img class="slideimg" src="images/Slide/01.jpg" alt="image not found"></img>
          </div>
          <div class="imageSlides">  
              <img class="slideimg" src="images/Slide/02.jpg" alt="image not found"></img>
          </div>
          <div class="imageSlides">  
              <img class="slideimg" src="images/Slide/03.jpg" alt="image not found"></img>
          </div>
          <div class="wow lightSpeedIn text" data-wow-delay="0.3s">
            <h4><?php echo $slider_head;?></h4>
            <p><?php echo $slider_head2;?></p>
            <a href=""><?php echo $read_more;?></a>
          </div>
          <span id="rightArrow" class="slideshowArrow"></span>
          <span id="leftArrow" class="slideshowArrow"></span>
          <div class="slideshowCircles">
              <span class="circle dot"></span>
              <span class="circle"></span>
              <span class="circle"></span>
          </div>
        </div>
        
        <!-- STOP SLIDER -->

        <!-- START PAGE CONTENT -->

        <div class="main_content">
          <div class="container">
            <div class="row">
              <div class="col-8 wow bounceInLeft" data-wow-delay="0.3s">
                <div class="holder big">
                  <h4><?php echo $about_h1;?></h4>
                  <p><?php echo $about_c1;?></p>
                </div>
              </div>
              <div class="col-4 wow bounceInRight" data-wow-delay="0.3s">
                <div class="holder">
                  <div class="small_slide">
                    <div class="product-slider-1 owl-carousel">
                      <div class="product-item">
                          <div class="pi-pic">
                            <img src="images/product/helmet-500x320.png">
                          </div>
                      </div>
                      <div class="product-item">
                          <div class="pi-pic">
                            <img src="images/product/hammer-500x320.png">
                          </div>
                      </div>
                      <div class="product-item">
                          <div class="pi-pic">
                            <img src="images/product/plaster-500x320.png">
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-6 wow bounceInUp" data-wow-delay="0.3s">
                <div class="holder little">
                  <div class="icon">
                    <i class="fa fa-eye"></i>
                  </div>
                  <h4><?php echo $about_h2;?></h4>
                  <p><?php echo $about_c2;?></p>
                </div>
              </div>
              <div class="col-6 wow bounceInUp" data-wow-delay="0.3s">
                <div class="holder little">
                  <div class="icon">
                    <i class="fa fa-bullseye"></i>
                  </div>
                  <h4><?php echo $about_h3;?></h4>
                  <p><?php echo $about_c3;?></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="categories">
          <div class="container">
            <div class="row">
              <?php getCategories($conn);?>
            </div>
          </div>
        </div>
        <!-- STOP PAGE CONTENT -->
        
        <!-- START SINGLE LINE SLIDE -->
        <div class="inline_slide">
          <div class="container">
            <div class="product-slider owl-carousel">
              <?php getProductsHome($conn);?>
            </div>
          </div>
        </div>  

        <!-- STOP SINGLE LINE SLIDE -->

        <!-- START ABOUT US -->
        <div class="main_content">
          <div class="container">
            <div class="holder big wow bounceInLeft" data-wow-delay="0.3s">
              <h4><?php echo $about_h4;?></h4>
              <p><?php echo $about_c4_1;?></p>
              <p><?php echo $about_c4_2;?></p>
              <p><?php echo $about_c4_3;?></p>
              <p><?php echo $about_c4_4;?></p>
              <div class="row">
                <div class="col-8"></div>
                <div class="col-4">
                  <a href="about"><?php echo $read_more;?></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- STOP ABOUT US -->

        <!-- START SINGLE LINE SLIDE -->
        
        <div class="inline_slide bottom">
          <div class="container">
            <div class="title">
              <div class="icon">
                <svg fill="white" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 1000 1000" enable-background="new 0 0 1000 1000" xml:space="preserve">
                  <g>  
                    <g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)">
                      <path d="M4714.9,4902.8l-259.3-115.2l-293.9,32.7l-293.9,32.7l-163.3-151.7c-268.9-245.8-261.2-242-562.8-303.5c-311.2-61.5-272.8-32.7-453.3-351.5c-59.5-107.6-132.5-213.2-161.3-232.4c-26.9-19.2-146-88.3-261.2-153.7l-213.2-117.2l-55.7-284.3l-57.6-282.4l-199.8-219l-199.8-217l32.6-292l30.7-293.9L1488,1700.9c-63.4-140.2-115.2-265.1-115.2-280.4c0-15.4,51.9-140.2,115.2-280.4l115.2-253.5l-30.7-293.9l-32.6-291.9l199.8-217.1l199.8-219l57.6-282.4l55.7-280.4l243.9-136.4c134.5-76.8,255.5-151.7,270.8-169c13.4-17.3,86.4-134.4,159.4-261.2l134.5-232.4l286.2-59.5l286.2-59.6l219-197.8l217-197.8l293.9,32.7l292,32.7l236.3-107.6c130.6-57.6,253.5-111.4,274.7-117.2c23-7.7,132.5,30.7,299.6,105.6l265.1,119.1l292-32.7L6117-2012l217,197.8l219,197.8l286.2,59.6l286.2,57.6l144.1,253.5L7413.6-994l211.3,121C7961-682.8,7928.3-725,7991.7-410l55.7,274.7l172.9,188.2c249.7,272.8,230.5,217,192.1,547.4l-30.7,284.3l115.2,255.5c65.3,142.1,117.2,267,117.2,280.4c0,13.5-51.9,138.3-117.2,280.4l-115.2,255.5l30.7,284.3c38.4,330.4,57.6,272.7-192.1,547.4l-172.9,188.2l-57.6,282.4l-55.7,284.3l-249.7,138.3c-272.7,153.7-261.2,140.2-462.9,497.5l-92.2,163.3l-280.4,57.6c-307.3,61.5-280.4,46.1-562.8,301.6l-167.1,151.7l-293.9-32.7l-293.9-32.7l-263.1,117.2c-144.1,65.3-268.9,117.2-278.5,115.2C4981.9,5020,4857,4968.1,4714.9,4902.8z M5512,3831c681.9-147.9,1256.2-562.8,1621.1-1169.8c670.3-1114,324.6-2581.5-776-3298C6070.9-823,5805.9-930.6,5464-1003.6c-226.7-46.1-714.5-46.1-941.2,0C3506.7-788.4,2771.1-56.6,2552.1,959.5c-46.1,213.2-46.1,708.8,0,922C2675,2450,2943.9,2909,3366.5,3275.9c357.3,311.2,831.7,528.2,1300.4,591.6C4878.1,3896.3,5291.1,3879,5512,3831z"/><path d="M4643.8,3379.6c-286.2-51.9-622.3-195.9-843.2-361.1c-134.5-101.8-376.5-351.5-462.9-474.4c-299.6-437.9-414.9-1012.2-303.5-1530.9c195.9-920,1014.2-1580.8,1959.2-1580.8c1267.7,0,2222.3,1164,1959.2,2395.2c-167.1,791.3-816.3,1411.8-1621.1,1552C5137.5,3414.2,4832.1,3414.2,4643.8,3379.6z M5940.3,2215.6c155.6-115.2,284.3-217,286.2-224.7c5.8-15.4-1179.3-1565.4-1202.4-1575c-15.4-5.8-1237,900.8-1256.2,931.6c-9.6,15.4,409.1,578.1,436,587.7c5.8,1.9,149.8-101.8,318.8-232.4c170.9-130.6,322.7-242,336.1-245.9c15.4-5.8,132.5,128.7,309.2,361.1c363,474.4,470.6,610.8,480.2,610.8C5652.2,2428.9,5784.8,2332.8,5940.3,2215.6z"/><path d="M1491.8-1973.5c-351.5-518.6-633.9-948.8-624.2-956.5c11.5-11.5,1338.8-434.1,1603.8-510.9c17.3-5.8,286.2-313.1,593.5-683.8c518.6-620.4,564.7-670.3,587.8-637.7c15.4,21.1,291.9,424.5,614.6,898.9l585.8,862.4l-265.1,389.9c-199.8,295.8-274.7,391.8-303.5,391.8c-44.2,0-357.3-34.6-439.9-48c-44.2-7.7-82.6,19.2-268.9,186.3c-117.2,105.7-232.4,203.6-253.5,217.1c-21.1,15.4-155.6,48-297.7,76.8c-142.1,26.9-276.6,57.6-297.7,65.3c-21.1,9.6-105.6,132.5-186.3,276.6c-163.3,282.4-153.7,270.8-303.5,355.3l-105.6,59.5L1491.8-1973.5z"/><path d="M7730.5-1103.4c-121-69.1-128.7-78.7-280.4-338c-86.4-147.9-172.9-272.8-192.1-282.4c-21.1-7.7-153.7-36.5-295.8-65.3c-142.1-26.9-278.5-63.4-303.5-78.7c-25-15.4-138.3-113.3-253.6-217c-192.1-174.8-215.1-190.2-272.7-180.6c-34.6,3.8-174.8,21.1-311.2,36.5l-249.7,26.9l-288.1-130.6l-290-128.7l-161.3,73l-159.4,73l34.6-51.9c92.2-144.1,1626.9-2399,1638.4-2412.5c9.6-9.6,268.9,286.2,578.1,656.9l560.9,670.3l147.9,46.1c80.7,25,451.4,140.2,822.1,257.4c372.6,115.2,678,215.1,678,224.7c0,9.6-1233.1,1836.2-1275.4,1890C7855.3-1032.4,7797.7-1063.1,7730.5-1103.4z"/>
                    </g>
                  </g>
                </svg>
              </div>
              <h4><?php echo $our_brands;?></h4>
            </div>
            <div class="product-slider owl-carousel">
              <?php getBrands($conn);?>
            </div>
          </div>
        </div>  

        <!-- STOP SINGLE LINE SLIDE -->
        <?php echo $footer; ?>
